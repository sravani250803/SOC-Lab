package www.calc.org;

public class Calculator {
public double sum (double x, double y) {
	return x+y;
}
}
